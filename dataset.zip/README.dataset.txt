# My First Project > 2026-01-05 10:05pm
https://universe.roboflow.com/trial-hrr5u/my-first-project-qthgw

Provided by a Roboflow user
License: CC BY 4.0

